export interface Slide {
  id: number;
  title: string;
  subtitle?: string;
  theme: 'blue' | 'green' | 'orange' | 'red' | 'neutral';
  speakerNotes: string[];
}

export interface Competitor {
  name: string;
  model: string;
  pricing: string;
  target: string;
  strengths: string[];
  weaknesses: string[];
}

export interface PDFInsight {
  category: 'Market' | 'Competition' | 'Regulation' | 'Economics' | 'Strategy';
  title: string;
  detail: string;
  metric?: string;
  sourcePage: number;
}
