import { useState } from 'react';
import SlideViewer from './components/SlideViewer';
import ExecutiveSummary from './components/ExecutiveSummary';
import QAPartner from './components/QAPartner';
import { slides } from './data';
import { Presentation, BookOpen, MessageSquare, Shield, HelpCircle, LayoutGrid, Sparkles, Printer, User, Award, FileText } from 'lucide-react';
import { motion } from 'motion/react';

export default function App() {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [showSpeakerNotes, setShowSpeakerNotes] = useState(true);
  const [activeTab, setActiveTab] = useState<'notes' | 'summary' | 'copilot'>('notes');
  const [viewMode, setViewMode] = useState<'presentation' | 'all-slides'>('presentation');

  const currentSlide = slides[currentSlideIndex];

  // Printable view trigger
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-[#030712] text-slate-200 font-sans flex flex-col selection:bg-blue-600 selection:text-white relative overflow-x-hidden print:bg-white print:text-black">
      
      {/* Background Ambient Glows */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-20 -left-20 w-96 h-96 bg-blue-600/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-indigo-600/5 rounded-full blur-[150px]" />
      </div>

      {/* Top Professional Header Bar */}
      <header className="bg-slate-900/40 border-b border-slate-800 px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 sticky top-0 z-40 backdrop-blur-md print:hidden">
        <div className="flex items-center gap-3">
          <div className="bg-blue-600 text-white p-2 rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(59,130,246,0.5)]">
            <Presentation className="w-5 h-5" />
          </div>
          <div className="flex flex-col">
            <h1 className="text-base font-extrabold tracking-tight text-white flex items-center gap-2">
              US Teledermatology Market Assessment
            </h1>
            <p className="text-[11px] text-slate-400 font-semibold flex items-center gap-1">
              <User className="w-3 h-3 text-slate-500" />
              Pitch Deck & Investor Command Center • Prepared by Anish Bera
            </p>
          </div>
        </div>

        {/* Presentation Control Widgets */}
        <div className="flex items-center gap-2">
          {/* Deck View / All Slides Toggle */}
          <div className="bg-slate-950 p-1 rounded-xl flex items-center border border-slate-800">
            <button
              onClick={() => setViewMode('presentation')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                viewMode === 'presentation'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Presentation className="w-3.5 h-3.5" />
              Presentation
            </button>
            <button
              onClick={() => setViewMode('all-slides')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                viewMode === 'all-slides'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              All Slides
            </button>
          </div>

          {/* Print Button */}
          <button
            onClick={handlePrint}
            className="bg-slate-900 hover:bg-slate-800 text-slate-200 font-bold text-xs border border-slate-800 rounded-xl px-3 py-2 flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
            title="Print Executive Dossier"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Deck
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-[1400px] w-full mx-auto p-4 sm:p-6 flex flex-col gap-6 relative z-10">
        
        {viewMode === 'presentation' ? (
          /* PRESENTATION DECK MODE */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left Frame: Slide Player (7/12 width) */}
            <div className="lg:col-span-7 flex flex-col gap-4">
              <SlideViewer
                currentSlideIndex={currentSlideIndex}
                onSlideChange={setCurrentSlideIndex}
                showSpeakerNotes={showSpeakerNotes}
                onToggleSpeakerNotes={() => setShowSpeakerNotes(!showSpeakerNotes)}
              />
            </div>

            {/* Right Frame: Command Sidebar panel (5/12 width) */}
            <div className="lg:col-span-5 flex flex-col gap-4">
              
              {/* Sidebar Tabs */}
              <div className="bg-slate-900/60 p-1 rounded-2xl border border-slate-800 flex shadow-lg backdrop-blur-sm">
                <button
                  onClick={() => setActiveTab('notes')}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                    activeTab === 'notes'
                      ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(59,130,246,0.3)]'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  Speaker Notes
                </button>
                <button
                  onClick={() => setActiveTab('summary')}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                    activeTab === 'summary'
                      ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(59,130,246,0.3)]'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  PDF Summary
                </button>
                <button
                  onClick={() => setActiveTab('copilot')}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                    activeTab === 'copilot'
                      ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(59,130,246,0.3)]'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  Pitch Co-Pilot
                </button>
              </div>

              {/* Sidebar Content Display */}
              <div className="min-h-[400px]">
                {/* TAB 1: Presenter Speaker Notes */}
                {activeTab === 'notes' && (
                  <div className="bg-slate-900/50 rounded-2xl p-5 border border-slate-800/80 backdrop-blur-md shadow-xl flex flex-col gap-4">
                    <div className="border-b border-slate-800 pb-3">
                      <h3 className="text-white font-extrabold text-sm tracking-tight flex items-center gap-2">
                        <BookOpen className="w-4 h-4 text-blue-400" />
                        Slide {currentSlideIndex + 1} Presenter Notes
                      </h3>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        In-depth statistics and clinical cues drawn from the regulatory dossier for this specific slide.
                      </p>
                    </div>

                    <div className="flex flex-col gap-3 min-h-[220px]">
                      {currentSlide.speakerNotes.map((note, idx) => (
                        <div key={idx} className="flex items-start gap-3 bg-slate-950/40 p-3 rounded-xl border border-slate-800/60">
                          <span className="bg-slate-800 text-slate-300 border border-slate-700 font-mono font-bold text-[9px] w-5 h-5 rounded-md flex items-center justify-center shrink-0">
                            {idx + 1}
                          </span>
                          <p className="text-[11px] text-slate-300 font-medium leading-relaxed">
                            {note}
                          </p>
                        </div>
                      ))}
                    </div>

                    <div className="bg-slate-950/40 border border-slate-800 p-3 rounded-xl text-[10px] text-slate-400 font-semibold flex items-start gap-2">
                      <HelpCircle className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                      <span>
                        Tip: Maintain steady pacing. Focus heavily on state licensing (IMLC rules) and why specialized chronic disease care (eczema) triggers high recurring LTV compared to general transactional apps.
                      </span>
                    </div>
                  </div>
                )}

                {/* TAB 2: Searchable PDF Summary Dossier */}
                {activeTab === 'summary' && <ExecutiveSummary />}

                {/* TAB 3: AI Co-Pilot Q&A chatbot */}
                {activeTab === 'copilot' && <QAPartner />}
              </div>

            </div>
          </div>
        ) : (
          /* ALL SLIDES GRID OVERVIEW MODE */
          <div className="flex flex-col gap-6">
            <div className="bg-slate-900/50 p-5 rounded-2xl border border-slate-800/80 shadow-xl backdrop-blur-md">
              <h3 className="text-white font-extrabold text-base tracking-tight flex items-center gap-2">
                <LayoutGrid className="w-5 h-5 text-white" />
                Dossier Pitch Deck Overview (All Slides)
              </h3>
              <p className="text-slate-400 text-xs mt-0.5">
                Overview of the 10-slide strategy deck for Anish Bera's US Teledermatology Market Entry analysis.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {slides.map((slide, idx) => (
                <div
                  key={slide.id}
                  onClick={() => {
                    setCurrentSlideIndex(idx);
                    setViewMode('presentation');
                  }}
                  className="bg-slate-900/40 rounded-2xl p-5 border border-slate-800 hover:border-blue-500/80 hover:shadow-[0_0_20px_rgba(59,130,246,0.15)] transition-all duration-200 cursor-pointer flex flex-col justify-between h-[220px] backdrop-blur-sm group"
                >
                  <div className="flex flex-col gap-1.5">
                    <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">
                      SLIDE {idx + 1} • {slide.theme.toUpperCase()}
                    </span>
                    <h4 className="text-sm font-black text-white tracking-tight leading-tight group-hover:text-blue-400 transition-colors">
                      {slide.title}
                    </h4>
                    {slide.subtitle && (
                      <p className="text-[10px] text-slate-400 truncate font-medium">
                        {slide.subtitle}
                      </p>
                    )}
                  </div>

                  <p className="text-[11px] text-slate-400 line-clamp-3 leading-relaxed mt-4">
                    {slide.speakerNotes[0]}
                  </p>

                  <div className="border-t border-slate-800 pt-2.5 mt-3 flex justify-between items-center text-[9px] text-slate-500 font-bold">
                    <span>Notes: {slide.speakerNotes.length} items</span>
                    <span className="text-blue-400 group-hover:underline">Click to present</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Corporate Professional Footer */}
      <footer className="bg-slate-950/40 border-t border-slate-800 px-6 py-4 text-center text-xs text-slate-500 font-medium mt-auto relative z-10 backdrop-blur-sm print:hidden">
        <div className="max-w-[1400px] mx-auto flex flex-col sm:flex-row sm:justify-between items-center gap-2">
          <span>© 2026 Teledermatology Market Entry Evaluation. Prepared for Pitch Board Review.</span>
          <span className="text-slate-400 font-semibold flex items-center gap-2">
            <Award className="w-3.5 h-3.5 text-slate-500" />
            Anish Bera, Lead Market Strategist
            <span className="inline-flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-[10px] text-slate-500">System Sync: Active</span>
            </span>
          </span>
        </div>
      </footer>
    </div>
  );
}
