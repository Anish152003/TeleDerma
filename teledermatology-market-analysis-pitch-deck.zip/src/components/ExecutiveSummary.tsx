import { useState } from 'react';
import { pdfInsights } from '../data';
import { Search, BookOpen, AlertTriangle, FileText, Compass, Sparkles } from 'lucide-react';

export default function ExecutiveSummary() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Market' | 'Competition' | 'Regulation' | 'Economics' | 'Strategy'>('All');

  const filteredInsights = pdfInsights.filter((insight) => {
    const matchesSearch =
      insight.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      insight.detail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      insight.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || insight.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categoryIcons = {
    Market: <Compass className="w-4 h-4 text-blue-400" />,
    Competition: <Sparkles className="w-4 h-4 text-orange-400" />,
    Regulation: <AlertTriangle className="w-4 h-4 text-rose-400" />,
    Economics: <FileText className="w-4 h-4 text-slate-400" />,
    Strategy: <BookOpen className="w-4 h-4 text-emerald-400" />,
  };

  return (
    <div className="bg-slate-900/40 backdrop-blur-md rounded-2xl p-5 shadow-2xl border border-slate-850 flex flex-col gap-4 h-full">
      {/* Header */}
      <div className="flex flex-col gap-1 border-b border-slate-850 pb-3">
        <h3 className="text-white font-extrabold text-lg tracking-tight flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-blue-400" />
          Teledermatology Executive Summary & Deep-Dive Context
        </h3>
        <p className="text-slate-400 text-xs font-medium">
          Drawn from in-depth analysis of regulatory constraints, clinician supply, and corporate operational records.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-2.5">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search PDF insights (e.g. shortage, HIPAA, parity)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-950 focus:bg-slate-900 border border-slate-800 focus:border-blue-500 rounded-xl outline-none transition-all placeholder:text-slate-500 text-white"
          />
        </div>

        {/* Category Selector */}
        <div className="flex gap-1 overflow-x-auto pb-1 sm:pb-0 shrink-0">
          {(['All', 'Market', 'Competition', 'Regulation', 'Economics', 'Strategy'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white shadow-[0_0_10px_rgba(59,130,246,0.3)]'
                  : 'bg-slate-950 hover:bg-slate-900 text-slate-400 border border-slate-850/85'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Highlights Bento Box */}
      {searchQuery === '' && selectedCategory === 'All' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div className="bg-blue-950/25 p-3 rounded-xl border border-blue-900/30 flex flex-col justify-between">
            <span className="text-[9px] font-bold text-blue-400 uppercase tracking-wide">Macro CAGR</span>
            <span className="text-lg font-black text-blue-100 mt-1 font-mono">17%</span>
            <span className="text-[9px] text-blue-300 mt-1 leading-snug">Projected Growth 2024-2030</span>
          </div>
          <div className="bg-rose-950/15 p-3 rounded-xl border border-rose-900/20 flex flex-col justify-between">
            <span className="text-[9px] font-bold text-rose-400 uppercase tracking-wide">Shortage Constraint</span>
            <span className="text-lg font-black text-rose-100 mt-1 font-mono">3.4</span>
            <span className="text-[9px] text-rose-300 mt-1 leading-snug">Dermatologists per 100k people</span>
          </div>
          <div className="bg-emerald-950/15 p-3 rounded-xl border border-emerald-900/20 flex flex-col justify-between col-span-2 sm:col-span-1">
            <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-wide">In-Patient Wait</span>
            <span className="text-lg font-black text-emerald-100 mt-1 font-mono">4 Mos</span>
            <span className="text-[9px] text-emerald-300 mt-1 leading-snug">Average time for consults</span>
          </div>
        </div>
      )}

      {/* Scrollable list of PDF insights */}
      <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-3 min-h-[220px] max-h-[350px]">
        {filteredInsights.length > 0 ? (
          filteredInsights.map((insight, idx) => (
            <div
              key={idx}
              className="group bg-slate-950/40 hover:bg-slate-900/60 border border-slate-850 hover:border-slate-800 rounded-xl p-3.5 transition-all duration-200 flex flex-col gap-1.5"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  {categoryIcons[insight.category]}
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 group-hover:text-slate-400 transition-colors">
                    {insight.category}
                  </span>
                </div>
                <span className="bg-slate-950 px-2 py-0.5 rounded-md border border-slate-850/80 font-mono text-[9px] font-bold text-slate-400">
                  PDF Page {insight.sourcePage}
                </span>
              </div>

              <div className="flex justify-between items-start gap-4">
                <div className="flex-1 flex flex-col gap-1">
                  <h4 className="text-xs font-bold text-slate-200 tracking-tight group-hover:text-white transition-colors">
                    {insight.title}
                  </h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed group-hover:text-slate-300 transition-colors">
                    {insight.detail}
                  </p>
                </div>
                {insight.metric && (
                  <span className="bg-slate-900 group-hover:bg-blue-950/40 font-mono text-[10px] font-extrabold text-slate-300 group-hover:text-blue-400 px-2 py-1 rounded-lg border border-slate-850 group-hover:border-blue-900/30 transition-all shrink-0">
                    {insight.metric}
                  </span>
                )}
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-10 text-slate-500 flex flex-col items-center gap-2">
            <Search className="w-8 h-8 text-slate-600 stroke-[1.5]" />
            <p className="text-xs">No insights match your query. Try another keyword!</p>
          </div>
        )}
      </div>
    </div>
  );
}
