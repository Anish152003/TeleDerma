import { useState, useEffect } from 'react';
import { slides } from '../data';
import { Slide } from '../types';
import { ChevronLeft, ChevronRight, Presentation, HelpCircle, FileText, Check, X, ShieldAlert, AlertTriangle, Play, BookOpen, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import MarketChart from './MarketChart';
import CompetitorMatrix from './CompetitorMatrix';
import EconomicsSimulator from './EconomicsSimulator';

interface SlideViewerProps {
  currentSlideIndex: number;
  onSlideChange: (index: number) => void;
  showSpeakerNotes: boolean;
  onToggleSpeakerNotes: () => void;
}

export default function SlideViewer({
  currentSlideIndex,
  onSlideChange,
  showSpeakerNotes,
  onToggleSpeakerNotes
}: SlideViewerProps) {
  const currentSlide = slides[currentSlideIndex];

  const nextSlide = () => {
    if (currentSlideIndex < slides.length - 1) {
      onSlideChange(currentSlideIndex + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlideIndex > 0) {
      onSlideChange(currentSlideIndex - 1);
    }
  };

  // Listen to keyboard arrow keys for navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'Space') {
        e.preventDefault();
        nextSlide();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        prevSlide();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentSlideIndex]);

  // Determine slide background theme classes
  const getThemeClasses = (theme: Slide['theme']) => {
    switch (theme) {
      case 'blue':
        return {
          bg: 'bg-slate-900/40 border-slate-800 backdrop-blur-md shadow-[0_0_30px_rgba(59,130,246,0.05)]',
          accent: 'text-blue-400 border-blue-900/50 bg-blue-950/40',
          border: 'border-slate-800/80',
          pill: 'bg-blue-500 shadow-[0_0_10px_#3b82f6]'
        };
      case 'green':
        return {
          bg: 'bg-slate-900/40 border-slate-800 backdrop-blur-md shadow-[0_0_30px_rgba(16,185,129,0.05)]',
          accent: 'text-emerald-400 border-emerald-900/50 bg-emerald-950/40',
          border: 'border-slate-800/80',
          pill: 'bg-emerald-500 shadow-[0_0_10px_#10b981]'
        };
      case 'orange':
        return {
          bg: 'bg-slate-900/40 border-slate-800 backdrop-blur-md shadow-[0_0_30px_rgba(249,115,22,0.05)]',
          accent: 'text-orange-400 border-orange-900/50 bg-orange-950/40',
          border: 'border-slate-800/80',
          pill: 'bg-orange-500 shadow-[0_0_10px_#f97316]'
        };
      case 'red':
        return {
          bg: 'bg-slate-900/40 border-slate-800 backdrop-blur-md shadow-[0_0_30px_rgba(239,68,68,0.05)]',
          accent: 'text-rose-400 border-rose-900/50 bg-rose-950/40',
          border: 'border-slate-800/80',
          pill: 'bg-rose-500 shadow-[0_0_10px_#ef4444]'
        };
      default:
        return {
          bg: 'bg-slate-900/40 border-slate-800 backdrop-blur-md',
          accent: 'text-slate-400 border-slate-800 bg-slate-950/40',
          border: 'border-slate-800/80',
          pill: 'bg-blue-500 shadow-[0_0_10px_#3b82f6]'
        };
    }
  };

  const themeClasses = getThemeClasses(currentSlide.theme);

  return (
    <div className="flex flex-col gap-4">
      {/* Slide Canvas Frame */}
      <div className={`relative rounded-3xl border border-slate-800/80 shadow-2xl ${themeClasses.bg} p-6 sm:p-8 min-h-[500px] flex flex-col justify-between transition-all duration-300`}>
        
        {/* Slide Top Header Row */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-850">
          <div className="flex items-center gap-2.5">
            <span className={`w-2.5 h-2.5 rounded-full ${themeClasses.pill} animate-pulse`} />
            <span className="text-[10px] uppercase font-black tracking-wider text-slate-500">
              Slide {currentSlideIndex + 1} of {slides.length}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] bg-slate-950 text-slate-400 font-bold px-2 py-0.5 rounded-md border border-slate-800/60 flex items-center gap-1">
              <Clock className="w-2.5 h-2.5" />
              Pitch Deck
            </span>
            <button
              onClick={onToggleSpeakerNotes}
              className={`text-[10px] font-bold px-2.5 py-0.5 rounded-md border transition-all ${
                showSpeakerNotes
                  ? 'bg-blue-600 text-white border-blue-600 shadow-[0_0_10px_rgba(59,130,246,0.5)]'
                  : 'bg-slate-950 hover:bg-slate-900 text-slate-400 border-slate-800/80'
              }`}
            >
              Notes
            </button>
          </div>
        </div>

        {/* Slide Content Display with Animating Transitions */}
        <div className="flex-1 py-6 flex flex-col justify-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              className="flex flex-col gap-4 h-full"
            >
              {/* Slide Title & Subtitle block */}
              <div className="flex flex-col gap-1 max-w-2xl border-l-4 border-blue-500 pl-4">
                <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-tight">
                  {currentSlide.title}
                </h2>
                {currentSlide.subtitle && (
                  <p className="text-xs text-slate-400 font-medium leading-relaxed">
                    {currentSlide.subtitle}
                  </p>
                )}
              </div>

              {/* Render Custom Slide Content Layouts Based on ID */}
              <div className="mt-4 flex-1">
                {/* SLIDE 1: Title Card */}
                {currentSlide.id === 1 && (
                  <div className="flex flex-col items-center justify-center text-center py-12 gap-5">
                    <div className="bg-slate-950 text-blue-400 border border-slate-800 rounded-full p-3.5 shadow-[0_0_20px_rgba(59,130,246,0.15)] flex items-center justify-center animate-bounce">
                      <Presentation className="w-8 h-8 stroke-[1.5]" />
                    </div>
                    <div className="flex flex-col gap-1">
                      <span className="text-[11px] font-black text-blue-400 tracking-widest uppercase">PITCH DECK PRESENTATION</span>
                      <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tighter leading-none mt-1">
                        US Teledermatology Market Analysis
                      </h1>
                      <p className="text-sm font-semibold text-slate-400 mt-2">
                        Market Entry Assessment & Operational Evaluation
                      </p>
                    </div>
                    <div className="mt-6 border-t border-slate-800/80 pt-5 flex flex-col items-center gap-1 text-[11px] text-slate-500">
                      <span className="font-bold text-slate-300 text-xs">Prepared by: Anish Bera</span>
                      <span>Strategic Market Operations Division</span>
                    </div>
                  </div>
                )}

                {/* SLIDE 2: Market Opportunity with SVG Chart */}
                {currentSlide.id === 2 && (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-center">
                    <div className="flex flex-col gap-4">
                      {/* CAGR metrics block */}
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                          <span className="text-[9px] font-bold text-blue-400 uppercase">2024 Base</span>
                          <span className="text-xl font-black text-white font-mono block mt-1">$4.3 Billion</span>
                        </div>
                        <div className="bg-blue-600 p-3 rounded-xl shadow-[0_0_15px_rgba(59,130,246,0.4)] text-white">
                          <span className="text-[9px] font-bold text-blue-100 uppercase">2030 Target</span>
                          <span className="text-xl font-black font-mono block mt-1">$11.3 Billion</span>
                        </div>
                      </div>

                      {/* Growth drivers bullet list */}
                      <div className="flex flex-col gap-2 bg-slate-950/40 p-4 rounded-xl border border-slate-800/80">
                        <span className="text-[10px] font-bold text-slate-400 uppercase">GROWTH DRIVERS</span>
                        <ul className="flex flex-col gap-1.5 text-xs text-slate-300 font-medium">
                          <li className="flex items-start gap-2">
                            <span className="text-blue-400 font-bold">•</span>
                            <span>Rising skin disease prevalence (87M+ Americans affected)</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-blue-400 font-bold">•</span>
                            <span>Severe dermatologist shortage (3.4 per 100k)</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-blue-400 font-bold">•</span>
                            <span>Long in-person clinical wait times (~4 months)</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    <div className="h-full">
                      <MarketChart />
                    </div>
                  </div>
                )}

                {/* SLIDE 3: Competitive Landscape Matrix */}
                {currentSlide.id === 3 && (
                  <div className="h-full">
                    <CompetitorMatrix />
                  </div>
                )}

                {/* SLIDE 4: Competitor Comparison (Strengths/Gaps) */}
                {currentSlide.id === 4 && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {/* Strengths & Weaknesses */}
                    <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80 flex flex-col gap-3.5">
                      <div className="flex flex-col gap-1">
                        <span className="text-[10px] font-bold text-emerald-400 uppercase">INCUMBENT ANALYSIS</span>
                        <h4 className="text-xs font-bold text-slate-300">Strengths & Core Weaknesses</h4>
                      </div>
                      <div className="flex flex-col gap-2.5">
                        <div className="bg-emerald-950/20 p-2.5 rounded-xl border border-emerald-900/30">
                          <span className="text-[9px] font-bold text-emerald-400">Strengths</span>
                          <p className="text-[11px] text-emerald-100 leading-relaxed mt-0.5">
                            Strong brand awareness, pre-negotiated insurer benefits, fast consultations, and direct medication shipping.
                          </p>
                        </div>
                        <div className="bg-slate-950/40 p-2.5 rounded-xl border border-slate-800">
                          <span className="text-[9px] font-bold text-slate-400">Weaknesses</span>
                          <p className="text-[11px] text-slate-300 leading-relaxed mt-0.5">
                            Primarily focused on one-time consultations. Poor chronic disease management, lack of skin AI, and mild acne limits.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Market Gap & Opportunities */}
                    <div className="bg-orange-950/10 p-4 rounded-2xl border border-orange-900/20 flex flex-col justify-between gap-3">
                      <div className="flex flex-col gap-1">
                        <span className="text-[10px] font-bold text-orange-400 uppercase">THE WHITE SPACE</span>
                        <h4 className="text-xs font-bold text-orange-100">No company owns long-term care</h4>
                      </div>
                      
                      <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800/80 shadow-inner flex flex-col gap-1">
                        <span className="text-[10px] font-extrabold text-orange-400">THE OPPORTUNITY:</span>
                        <ul className="flex flex-col gap-1 text-[11px] text-slate-300 font-medium">
                          <li className="flex items-center gap-1.5">
                            <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" />
                            <span>AI-assisted diagnosis & pre-screening</span>
                          </li>
                          <li className="flex items-center gap-1.5">
                            <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" />
                            <span>Chronic eczema & psoriasis management</span>
                          </li>
                          <li className="flex items-center gap-1.5">
                            <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" />
                            <span>Pediatric specialized care & monitoring</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                )}

                {/* SLIDE 5: Regulations & Compliance */}
                {currentSlide.id === 5 && (
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
                    {/* Compliance list */}
                    <div className="md:col-span-7 bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80 flex flex-col gap-3">
                      <span className="text-[10px] font-bold text-slate-400 uppercase">COMPLIANCE PROTOCOLS</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300">
                        {[
                          'HIPAA secure photo/video storage',
                          'State-by-state medical licensing',
                          'Complex physician credentialing',
                          'Inconsistent billing codes',
                          'State telehealth practice standards'
                        ].map((req, i) => (
                          <div key={i} className="flex items-start gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800/60">
                            <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                            <span className="text-[11px] font-medium leading-tight">{req}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Hardest Challenge block */}
                    <div className="md:col-span-5 bg-rose-950/20 p-4 rounded-2xl border border-rose-900/30 flex flex-col justify-between">
                      <div className="flex flex-col gap-1">
                        <span className="text-[10px] font-bold text-rose-400 uppercase flex items-center gap-1">
                          <ShieldAlert className="w-3.5 h-3.5" />
                          HARDEST CHALLENGE
                        </span>
                        <h4 className="text-xs font-black text-rose-100 mt-1">Physician State-by-State Licensure</h4>
                      </div>
                      <p className="text-[11px] text-rose-200 leading-relaxed my-3 font-medium">
                        Managing credentials across dozens of states while adhering to local telemedicine regulations is the highest barrier to scaling nationwide.
                      </p>
                      <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 text-[10px] text-rose-300 font-bold">
                        Requires Interstate Medical Licensure Compact (IMLC) setup.
                      </div>
                    </div>
                  </div>
                )}

                {/* SLIDE 6: Unit Economics Simulator */}
                {currentSlide.id === 6 && (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
                    <div className="lg:col-span-4 flex flex-col gap-3">
                      <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80 flex flex-col gap-1.5">
                        <span className="text-[9px] font-bold text-slate-500 uppercase">BENCHMARK REVENUE</span>
                        <span className="text-lg font-black text-white font-mono">$150 - $300 LTV</span>
                        <p className="text-[10px] text-slate-400">Based on subscription retention models.</p>
                      </div>
                      <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80 flex flex-col gap-1.5">
                        <span className="text-[9px] font-bold text-slate-500 uppercase">CLINICAL labor COST</span>
                        <span className="text-lg font-black text-white font-mono">~$40 / visit</span>
                        <p className="text-[10px] text-slate-400">Board-certified specialist payout.</p>
                      </div>
                    </div>
                    <div className="lg:col-span-8">
                      <EconomicsSimulator />
                    </div>
                  </div>
                )}

                {/* SLIDE 7: Founder Question 1 */}
                {currentSlide.id === 7 && (
                  <div className="flex flex-col gap-4">
                    <div className="bg-orange-950/40 border border-orange-850 text-white rounded-2xl p-4 shadow-md">
                      <span className="text-[9px] font-black uppercase tracking-widest text-orange-400">QUESTION 1: WHAT ASSUMPTION DO WE GET WRONG?</span>
                      <h3 className="text-sm font-black mt-1 leading-snug">"Most teledermatology startups assume that overall market growth alone guarantees profitability."</h3>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {[
                        { title: 'Expensive CAC', text: 'DTC healthcare acquisition is crowded and expensive; one-off transactions lead to negative margins.' },
                        { title: 'Patchy Coverage', text: 'Medicare/Medicaid regulations and commercial insurer payment parity remain highly inconsistent.' },
                        { title: 'The Retention Fix', text: 'To win, you must optimize patient retention (LTV) rather than just focusing on consultation volume.' }
                      ].map((card, i) => (
                        <div key={i} className="bg-slate-950/40 p-3 rounded-xl border border-slate-800 flex flex-col gap-1">
                          <span className="text-[10px] font-black text-orange-400">{card.title}</span>
                          <p className="text-[11px] text-slate-300 leading-relaxed font-medium">{card.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* SLIDE 8: Founder Question 2 */}
                {currentSlide.id === 8 && (
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
                    <div className="md:col-span-5 bg-blue-950/40 border border-blue-900/40 text-white rounded-2xl p-4.5 flex flex-col justify-between">
                      <div className="flex flex-col gap-1">
                        <span className="text-[9px] font-extrabold text-blue-400 uppercase">QUESTION 2</span>
                        <h3 className="text-base font-black mt-1">Why can a new company still win?</h3>
                      </div>
                      <p className="text-[11px] text-blue-100/95 leading-relaxed my-3 font-medium">
                        By avoiding general telehealth. Build a highly specialized dermatology experience that sells long-term skin health subscriptions.
                      </p>
                      <div className="text-[10px] text-emerald-400 font-bold bg-slate-950/60 p-2 rounded-xl border border-slate-800">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        Sell chronic skin health, not visits.
                      </div>
                    </div>

                    <div className="md:col-span-7 bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80 flex flex-col gap-2.5">
                      <span className="text-[10px] font-bold text-slate-400 uppercase">WINNING EXECUTION PLAYBOOK</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300">
                        {[
                          'AI image screening & melanoma triage',
                          'Longitudinal eczema/psoriasis loops',
                          'Personalized dermatological treatment plans',
                          'Better mobile-first photo upload UX',
                          'Faster specialist turnarounds (<2 days)'
                        ].map((play, i) => (
                          <div key={i} className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800/60">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0" />
                            <span className="text-[11px] font-semibold leading-tight">{play}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* SLIDE 9: Founder Question 3 */}
                {currentSlide.id === 9 && (
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
                    {/* Visual diagnosis */}
                    <div className="md:col-span-6 bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80 flex flex-col gap-3">
                      <span className="text-[10px] font-bold text-blue-400 uppercase">QUESTION 3: BETTING MY OWN MONEY</span>
                      <h4 className="text-xs font-extrabold text-slate-200">Why Teledermatology perfectly fits visual telehealth</h4>
                      <ul className="flex flex-col gap-2 text-[11px] text-slate-300 font-semibold">
                        <li className="flex items-center gap-1.5">
                          <Check className="w-4 h-4 text-blue-400 stroke-[3]" />
                          <span>Dermatology is 100% visual diagnosis</span>
                        </li>
                        <li className="flex items-center gap-1.5">
                          <Check className="w-4 h-4 text-blue-400 stroke-[3]" />
                          <span>Large underserved chronic patient base</span>
                        </li>
                        <li className="flex items-center gap-1.5">
                          <Check className="w-4 h-4 text-blue-400 stroke-[3]" />
                          <span>Subscription opportunities increase LTV</span>
                        </li>
                        <li className="flex items-center gap-1.5">
                          <Check className="w-4 h-4 text-blue-400 stroke-[3]" />
                          <span>AI image pre-screening boosts speed</span>
                        </li>
                      </ul>
                    </div>

                    {/* Investment thesis */}
                    <div className="md:col-span-6 bg-blue-950/10 p-4.5 rounded-2xl border border-blue-900/30 flex flex-col justify-between">
                      <div className="flex flex-col gap-1">
                        <span className="text-[9px] font-black text-blue-400 uppercase">INVESTMENT THESIS</span>
                        <h4 className="text-xs font-black text-blue-100 mt-1">High Growth, Lower CAPEX, Multi-Use cases</h4>
                      </div>
                      <p className="text-[11px] text-blue-100/90 leading-relaxed my-3 font-semibold">
                        "Teledermatology combines strong macro market growth, highly scalable image technology, and high-retention recurring subscriptions, making it one of the most attractive healthcare targets."
                      </p>
                      <div className="bg-blue-600 text-white p-2.5 rounded-xl font-bold text-[10px] text-center border border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.4)]">
                        17% CAGR + Subscription LTV = Strong Exit Potential
                      </div>
                    </div>
                  </div>
                )}

                {/* SLIDE 10: Final Recommendation */}
                {currentSlide.id === 10 && (
                  <div className="flex flex-col gap-4">
                    {/* Recommendation split */}
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
                      {/* YES */}
                      <div className="sm:col-span-3 bg-emerald-600 text-white rounded-2xl p-4 flex flex-col justify-center items-center gap-2.5 text-center shadow-[0_0_15px_rgba(16,185,129,0.4)]">
                        <span className="text-[9px] font-black uppercase text-emerald-100 tracking-wider">DECISION</span>
                        <span className="text-3xl font-black font-mono">YES</span>
                        <span className="text-[10px] font-extrabold bg-emerald-700 text-emerald-200 px-3 py-0.5 rounded-full border border-emerald-500">ENTER MARKET</span>
                      </div>

                      {/* Reasons */}
                      <div className="sm:col-span-5 bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80 flex flex-col gap-2">
                        <span className="text-[9px] font-bold text-emerald-400 uppercase">STRENGTHS / WHY ENTER</span>
                        <div className="flex flex-col gap-1.5 text-[11px] text-slate-300 font-semibold">
                          <div className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                            <span>$11.3B growing at 17% CAGR</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                            <span>Massive undersupply (4-mo waits)</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                            <span>AI efficiency gains & triage speed</span>
                          </div>
                        </div>
                      </div>

                      {/* Challenges */}
                      <div className="sm:col-span-4 bg-rose-950/15 p-4 rounded-2xl border border-rose-900/25 flex flex-col gap-2">
                        <span className="text-[9px] font-bold text-rose-400 uppercase">CHALLENGES / RISKS</span>
                        <div className="flex flex-col gap-1.5 text-[11px] text-rose-300 font-medium">
                          <div className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 bg-rose-500 rounded-full" />
                            <span>State licensure & compacts</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 bg-rose-500 rounded-full" />
                            <span>High consumer CAC (~$100)</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 bg-rose-500 rounded-full" />
                            <span>Reimbursement inconsistency</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Winning strategy bar */}
                    <div className="bg-emerald-950/10 text-slate-300 p-3.5 rounded-2xl border border-emerald-900/20 flex flex-col gap-1 shadow-sm">
                      <span className="text-[10px] font-black text-emerald-400 uppercase">WINNING PLAYBOOK STRATEGY</span>
                      <p className="text-[11px] font-medium leading-relaxed">
                        Build an <strong className="font-bold text-white">AI-first, chronic-care-focused</strong> teledermatology platform that maximizes patient retention instead of competing solely on consultation price.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Slide Bottom Controls Row */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-850 mt-4 text-xs">
          {/* Previous Button */}
          <button
            onClick={prevSlide}
            disabled={currentSlideIndex === 0}
            className={`flex items-center gap-1 font-bold px-3 py-1.5 rounded-xl border transition-all ${
              currentSlideIndex === 0
                ? 'opacity-30 cursor-not-allowed text-slate-600 border-transparent'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800 shadow-sm active:scale-95'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            Prev
          </button>

          {/* Slide Indicators Dots picker */}
          <div className="flex gap-1.5 items-center">
            {slides.map((s, idx) => {
              const isSelected = idx === currentSlideIndex;
              return (
                <button
                  key={s.id}
                  onClick={() => onSlideChange(idx)}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    isSelected ? `w-5 ${themeClasses.pill}` : 'w-2 bg-slate-800 hover:bg-slate-700'
                  }`}
                  title={`Go to slide ${idx + 1}`}
                />
              );
            })}
          </div>

          {/* Next Button */}
          <button
            onClick={nextSlide}
            disabled={currentSlideIndex === slides.length - 1}
            className={`flex items-center gap-1 font-bold px-3 py-1.5 rounded-xl border transition-all ${
              currentSlideIndex === slides.length - 1
                ? 'opacity-30 cursor-not-allowed text-slate-600 border-transparent'
                : 'bg-blue-600 hover:bg-blue-500 text-white border-blue-600 shadow-[0_0_10px_rgba(59,130,246,0.3)] active:scale-95'
            }`}
          >
            Next
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Slide Thumbnails Grid Row */}
      <div className="bg-slate-900/40 backdrop-blur-md rounded-2xl p-3 border border-slate-800/80 shadow-xl overflow-x-auto flex gap-2">
        {slides.map((slide, idx) => {
          const isSelected = idx === currentSlideIndex;
          return (
            <button
              key={slide.id}
              onClick={() => onSlideChange(idx)}
              className={`flex-shrink-0 text-left p-2.5 rounded-xl border transition-all w-[130px] flex flex-col gap-1 ${
                isSelected
                  ? 'bg-blue-600 text-white border-blue-600 shadow-[0_0_15px_rgba(59,130,246,0.3)]'
                  : 'bg-slate-950/60 hover:bg-slate-900 text-slate-400 border-slate-850/80'
              }`}
            >
              <span className={`text-[8px] font-black uppercase tracking-wider ${isSelected ? 'text-blue-300' : 'text-slate-500'}`}>
                Slide {idx + 1}
              </span>
              <span className="text-[10px] font-extrabold truncate max-w-full leading-tight">
                {slide.title}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
