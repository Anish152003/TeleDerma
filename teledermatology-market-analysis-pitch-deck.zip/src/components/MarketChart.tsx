import { useState } from 'react';
import { motion } from 'motion/react';

interface ChartData {
  year: string;
  value: number;
  label: string;
  isForecast: boolean;
}

const marketData: ChartData[] = [
  { year: '2022', value: 3.01, label: 'Historical ($3.01B)', isForecast: false },
  { year: '2024', value: 4.30, label: 'Current Base ($4.3B)', isForecast: false },
  { year: '2025', value: 5.05, label: 'Forecast ($5.1B)', isForecast: true },
  { year: '2026', value: 5.91, label: 'Forecast ($5.9B)', isForecast: true },
  { year: '2027', value: 6.91, label: 'Forecast ($6.9B)', isForecast: true },
  { year: '2028', value: 8.09, label: 'Forecast ($8.1B)', isForecast: true },
  { year: '2029', value: 9.46, label: 'Forecast ($9.5B)', isForecast: true },
  { year: '2030', value: 11.30, label: 'Target Market ($11.3B)', isForecast: true },
];

export default function MarketChart() {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const maxValue = 12;
  const chartHeight = 220;
  const chartWidth = 500;
  const paddingLeft = 40;
  const paddingRight = 20;
  const paddingTop = 20;
  const paddingBottom = 30;

  const getX = (index: number) => {
    return paddingLeft + (index / (marketData.length - 1)) * (chartWidth - paddingLeft - paddingRight);
  };

  const getY = (value: number) => {
    return chartHeight - paddingBottom - (value / maxValue) * (chartHeight - paddingTop - paddingBottom);
  };

  // Generate SVG path for line chart
  const linePath = marketData
    .map((d, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(d.value)}`)
    .join(' ');

  // Generate SVG path for area fill under the line
  const areaPath = `${linePath} L ${getX(marketData.length - 1)} ${getY(0)} L ${getX(0)} ${getY(0)} Z`;

  return (
    <div className="bg-slate-900/40 border border-slate-800/80 backdrop-blur-md rounded-2xl p-5 shadow-2xl flex flex-col h-full justify-between">
      <div>
        <div className="flex items-center justify-between mb-1">
          <h4 className="text-white font-bold text-sm tracking-tight">US Teledermatology Market Size ($ Billions)</h4>
          <span className="bg-blue-950/50 text-blue-400 font-semibold text-xs px-2.5 py-1 rounded-full border border-blue-900/50 animate-pulse">
            17% CAGR (2024-2030)
          </span>
        </div>
        <p className="text-slate-400 text-xs mb-4">
          Visual representation of rapid market growth, showing expansion from $4.3B in 2024 to $11.3B by 2030.
        </p>
      </div>

      <div className="relative w-full overflow-hidden" style={{ height: `${chartHeight}px` }}>
        <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-full overflow-visible">
          {/* Horizontal grid lines */}
          {[0, 3, 6, 9, 12].map((gridVal) => (
            <g key={gridVal}>
              <line
                x1={paddingLeft}
                y1={getY(gridVal)}
                x2={chartWidth - paddingRight}
                y2={getY(gridVal)}
                stroke="#1e293b"
                strokeWidth={1}
                strokeDasharray="4 4"
              />
              <text
                x={paddingLeft - 8}
                y={getY(gridVal) + 4}
                textAnchor="end"
                className="fill-slate-500 font-mono text-[10px]"
              >
                ${gridVal}B
              </text>
            </g>
          ))}

          {/* Area under the line */}
          <motion.path
            d={areaPath}
            fill="url(#area-gradient)"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.15 }}
            transition={{ duration: 1 }}
          />

          {/* Sparkle Line Path */}
          <motion.path
            d={linePath}
            fill="none"
            stroke="#3b82f6"
            strokeWidth={3}
            strokeLinecap="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.2, ease: 'easeOut' }}
          />

          {/* Dots on line for each year */}
          {marketData.map((d, i) => {
            const cx = getX(i);
            const cy = getY(d.value);
            const isHovered = hoveredIndex === i;

            return (
              <g key={d.year}>
                <circle
                  cx={cx}
                  cy={cy}
                  r={8}
                  fill="#3b82f6"
                  opacity={isHovered ? 0.4 : 0}
                  className="transition-opacity duration-200"
                />
                <circle
                  cx={cx}
                  cy={cy}
                  r={isHovered ? 5.5 : 4.5}
                  fill={d.isForecast ? '#60a5fa' : '#3b82f6'}
                  stroke="#0f172a"
                  strokeWidth={2}
                  className="cursor-pointer transition-all duration-200"
                  onMouseEnter={() => setHoveredIndex(i)}
                  onMouseLeave={() => setHoveredIndex(null)}
                />
                {/* Year labels on x-axis */}
                <text
                  x={cx}
                  y={chartHeight - 10}
                  textAnchor="middle"
                  className={`font-sans text-[10px] cursor-pointer transition-colors ${
                    isHovered ? 'fill-blue-400 font-semibold' : 'fill-slate-500'
                  }`}
                  onMouseEnter={() => setHoveredIndex(i)}
                  onMouseLeave={() => setHoveredIndex(null)}
                >
                  {d.year}
                </text>
              </g>
            );
          })}

          {/* Gradient definitions */}
          <defs>
            <linearGradient id="area-gradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>

        {/* Dynamic Tooltip overlay */}
        {hoveredIndex !== null && (
          <div
            className="absolute bg-slate-950 text-white rounded-lg px-2.5 py-1.5 shadow-2xl border border-slate-800 pointer-events-none transition-all duration-200 text-xs flex flex-col gap-0.5"
            style={{
              left: `${getX(hoveredIndex) - 60}px`,
              top: `${getY(marketData[hoveredIndex].value) - 60}px`,
              zIndex: 30,
            }}
          >
            <span className="font-bold text-blue-400 font-mono text-[10px]">YEAR {marketData[hoveredIndex].year}</span>
            <span className="font-semibold text-white">${marketData[hoveredIndex].value.toFixed(2)} Billion</span>
            <span className="text-[9px] text-slate-400 italic">{marketData[hoveredIndex].isForecast ? 'Forecast' : 'Reported'}</span>
          </div>
        )}
      </div>

      <div className="flex justify-between items-center bg-slate-950/40 rounded-xl px-4 py-2.5 text-slate-400 text-[11px] border border-slate-800/60">
        <span className="flex items-center gap-1.5 text-slate-300 font-medium">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block"></span>
          2022 Base: $3.01B
        </span>
        <span className="flex items-center gap-1.5 text-slate-300 font-medium">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block"></span>
          2024 Launch: $4.30B
        </span>
        <span className="flex items-center gap-1.5 text-slate-300 font-medium animate-pulse">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-400 inline-block"></span>
          2030 Goal: $11.30B
        </span>
      </div>
    </div>
  );
}
