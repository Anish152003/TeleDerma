import { useState, useRef, useEffect } from 'react';
import { pdfInsights } from '../data';
import { Send, Sparkles, MessageSquare, RefreshCw, Bookmark } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  references?: Array<{ title: string; page: number; metric?: string }>;
}

const presetQuestions = [
  'What is the biggest regulatory hurdle?',
  'Explain the dermatologist shortage numbers.',
  'How do Kaiser Permanente statistics apply?',
  'Detail the gross margin calculations.',
];

export default function QAPartner() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: "Hello! I am your Pitch Co-Pilot. I have crawled the full Market Opportunity & Unit Economics PDF dossier. Ask me any investor questions or click a preset below to test our pitch preparedness!",
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSendMessage = (text: string) => {
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    // Simulate smart semantic search over our rich pdfInsights database
    setTimeout(() => {
      const query = text.toLowerCase();
      const matchedInsights = pdfInsights.filter(
        (insight) =>
          insight.title.toLowerCase().includes(query) ||
          insight.detail.toLowerCase().includes(query) ||
          insight.category.toLowerCase().includes(query)
      );

      let replyText = '';
      let references: ChatMessage['references'] = [];

      if (matchedInsights.length > 0) {
        replyText = `Based on our teledermatology market PDF dossier, here is what we found regarding "${text}":\n\n`;
        matchedInsights.forEach((insight, idx) => {
          replyText += `• **${insight.title}**: ${insight.detail} ${
            insight.metric ? `(Metric: ${insight.metric})` : ''
          }\n\n`;
          references!.push({
            title: insight.title,
            page: insight.sourcePage,
            metric: insight.metric,
          });
        });
        replyText += `This directly supports our core strategy of building a specialized chronic care platform rather than a generalist one.`;
      } else {
        // Fallback generic but highly contextual answer based on overall data
        replyText = `I couldn't find a precise match in the PDF text for "${text}". However, based on our teledermatology market model:\n\n• **LTV / CAC**: Keeping CAC under ~$100 and increasing retention to push LTV past $300 is our key operational focus.\n• **State Barriers**: Managing state licensure is our toughest hurdle, but we leverage interstate compacts (IMLC) to speed this up.\n• **AI Triage**: We use pre-screening to increase specialist throughput by 40%.\n\nWould you like me to find details about licensing, wait times, or competitors?`;
      }

      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        text: replyText,
        references: references.length > 0 ? references : undefined,
      };

      setMessages((prev) => [...prev, assistantMsg]);
      setIsTyping(false);
    }, 1000);
  };

  const handleReset = () => {
    setMessages([
      {
        id: 'welcome',
        sender: 'assistant',
        text: "Hello! I am your Pitch Co-Pilot. I have crawled the full Market Opportunity & Unit Economics PDF dossier. Ask me any investor questions or click a preset below to test our pitch preparedness!",
      },
    ]);
  };

  return (
    <div className="bg-slate-900/40 border border-slate-800/80 backdrop-blur-md shadow-2xl flex flex-col h-[400px] rounded-2xl">
      {/* Header */}
      <div className="bg-slate-950 text-white rounded-t-2xl p-3.5 flex items-center justify-between border-b border-slate-850">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs font-extrabold tracking-tight text-white">AI Pitch Co-Pilot & Q&A Partner</span>
        </div>
        <button
          onClick={handleReset}
          className="text-slate-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-slate-900"
          title="Reset Chat"
        >
          <RefreshCw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Message Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 flex flex-col gap-3.5 bg-slate-950/20">
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex flex-col max-w-[85%] ${msg.sender === 'user' ? 'self-end items-end' : 'self-start'}`}
            >
              {/* Bubble */}
              <div
                className={`p-3 rounded-2xl text-[11px] leading-relaxed shadow-lg ${
                  msg.sender === 'user'
                    ? 'bg-blue-600 text-white rounded-tr-none shadow-[0_0_15px_rgba(59,130,246,0.3)] font-medium'
                    : 'bg-slate-900 text-slate-300 border border-slate-850 rounded-tl-none'
                }`}
              >
                {msg.text.split('\n\n').map((para, i) => (
                  <p key={i} className={i > 0 ? 'mt-2' : ''}>
                    {para.split('**').map((chunk, j) =>
                      j % 2 === 1 ? <strong key={j} className="font-bold text-white">{chunk}</strong> : chunk
                    )}
                  </p>
                ))}
              </div>

              {/* References */}
              {msg.references && (
                <div className="flex flex-wrap gap-1 mt-1.5 self-start">
                  {msg.references.map((ref, i) => (
                    <span
                      key={i}
                      className="inline-flex items-center gap-1 bg-blue-950/50 text-blue-400 text-[9px] font-bold px-2 py-0.5 rounded-md border border-blue-900/30"
                    >
                      <Bookmark className="w-2.5 h-2.5" />
                      {ref.title} (Page {ref.page})
                    </span>
                  ))}
                </div>
              )}
            </motion.div>
          ))}

          {isTyping && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-slate-900 border border-slate-850 rounded-2xl rounded-tl-none p-3 max-w-[100px] flex items-center justify-center gap-1 self-start"
            >
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" />
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]" />
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Presets and Input */}
      <div className="p-3 border-t border-slate-850 bg-slate-950/85 flex flex-col gap-2.5 rounded-b-2xl">
        {/* Suggested presets */}
        {messages.length === 1 && (
          <div className="flex flex-wrap gap-1">
            {presetQuestions.map((q) => (
              <button
                key={q}
                onClick={() => handleSendMessage(q)}
                className="text-[10px] bg-slate-900 hover:bg-slate-850 text-slate-400 border border-slate-800/80 px-2.5 py-1 rounded-lg text-left transition-all font-semibold"
              >
                {q}
              </button>
            ))}
          </div>
        )}

        {/* Input bar */}
        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="Type investor question (e.g. CAC, CAGR, Kaiser)..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage(inputValue)}
            className="flex-1 bg-slate-900 border border-slate-800 focus:border-blue-500 rounded-xl px-3 py-1.5 text-xs outline-none transition-all placeholder:text-slate-500 text-white"
          />
          <button
            onClick={() => handleSendMessage(inputValue)}
            className="bg-blue-600 hover:bg-blue-500 text-white rounded-xl p-2 transition-all shrink-0 shadow-[0_0_10px_rgba(59,130,246,0.3)]"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
