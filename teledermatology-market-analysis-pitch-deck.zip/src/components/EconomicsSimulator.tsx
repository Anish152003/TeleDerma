import { useState } from 'react';
import { motion } from 'motion/react';
import { DollarSign, ShieldAlert, Sparkles, TrendingUp } from 'lucide-react';

export default function EconomicsSimulator() {
  const [cac, setCac] = useState<number>(100);
  const [price, setPrice] = useState<number>(95);
  const [visits, setVisits] = useState<number>(2.5);
  const [cost, setCost] = useState<number>(40);

  // Calculations
  const ltv = price * visits;
  const ltvCacRatio = ltv / cac;
  const grossMargin = ((price - cost) / price) * 100;

  // Rating and color matching
  let statusText = 'CRITICAL (Unprofitable)';
  let statusColor = 'text-rose-400 bg-rose-950/20 border-rose-900/30';
  let badgeColor = 'bg-rose-500 shadow-[0_0_10px_rgba(239,68,68,0.3)]';
  if (ltvCacRatio >= 3) {
    statusText = 'TARGET ACQUIRED (Highly Profitable)';
    statusColor = 'text-emerald-400 bg-emerald-950/20 border-emerald-900/30';
    badgeColor = 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.3)]';
  } else if (ltvCacRatio >= 1.5) {
    statusText = 'WARNING (Moderate Margin / Risk)';
    statusColor = 'text-amber-400 bg-amber-950/20 border-amber-900/30';
    badgeColor = 'bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.3)]';
  }

  return (
    <div className="bg-slate-900/40 border border-slate-800/80 backdrop-blur-md rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
      <div>
        <h4 className="text-white font-bold text-sm tracking-tight flex items-center gap-1.5">
          <TrendingUp className="w-4 h-4 text-emerald-400" />
          Interactive Teledermatology Unit Economics Simulator
        </h4>
        <p className="text-slate-400 text-xs mt-0.5">
          Simulate variables to see how improving patient retention (Average Visits) exponentially increases LTV / CAC.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Sliders Panel */}
        <div className="flex flex-col gap-3.5">
          {/* Slider: Customer Acquisition Cost */}
          <div className="flex flex-col gap-1.5 bg-slate-950/60 p-3 rounded-xl border border-slate-850">
            <div className="flex justify-between items-center text-[11px]">
              <span className="font-bold text-slate-400">CAC (Acquisition Cost)</span>
              <span className="font-mono font-extrabold text-white">${cac}</span>
            </div>
            <input
              type="range"
              min={50}
              max={200}
              step={5}
              value={cac}
              onChange={(e) => setCac(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-850 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-[9px] text-slate-500">
              <span>$50 (Partnerships)</span>
              <span>$200 (Direct Ads)</span>
            </div>
          </div>

          {/* Slider: Self-pay Visit Price */}
          <div className="flex flex-col gap-1.5 bg-slate-950/60 p-3 rounded-xl border border-slate-850">
            <div className="flex justify-between items-center text-[11px]">
              <span className="font-bold text-slate-400">Visit Price (Self-Pay)</span>
              <span className="font-mono font-extrabold text-white">${price}</span>
            </div>
            <input
              type="range"
              min={75}
              max={150}
              step={5}
              value={price}
              onChange={(e) => setPrice(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-850 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-[9px] text-slate-500">
              <span>$75 (Discounted)</span>
              <span>$150 (Premium Care)</span>
            </div>
          </div>

          {/* Slider: Avg visits per user */}
          <div className="flex flex-col gap-1.5 bg-slate-950/60 p-3 rounded-xl border border-slate-850">
            <div className="flex justify-between items-center text-[11px]">
              <span className="font-bold text-slate-400 flex items-center gap-1">
                Avg Visits (Retention factor)
                <Sparkles className="w-3 h-3 text-yellow-500 animate-bounce" />
              </span>
              <span className="font-mono font-extrabold text-blue-400">{visits.toFixed(1)} visits</span>
            </div>
            <input
              type="range"
              min={1.0}
              max={5.0}
              step={0.1}
              value={visits}
              onChange={(e) => setVisits(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-850 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-[9px] text-slate-500">
              <span>1.0 (One-Off Visit)</span>
              <span>5.0 (Chronic Subscription)</span>
            </div>
          </div>

          {/* Slider: Doctor cost per visit */}
          <div className="flex flex-col gap-1.5 bg-slate-950/60 p-3 rounded-xl border border-slate-850">
            <div className="flex justify-between items-center text-[11px]">
              <span className="font-bold text-slate-400">Clinical Labor Cost / Visit</span>
              <span className="font-mono font-extrabold text-white">${cost}</span>
            </div>
            <input
              type="range"
              min={30}
              max={60}
              step={2}
              value={cost}
              onChange={(e) => setCost(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-850 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-[9px] text-slate-500">
              <span>$30 (High Efficiency)</span>
              <span>$60 (Premium Specialist)</span>
            </div>
          </div>
        </div>

        {/* Output Dashboard */}
        <div className="flex flex-col gap-3 justify-between bg-slate-950/80 text-white rounded-xl p-4 shadow-inner border border-slate-850">
          <div className="grid grid-cols-2 gap-3">
            {/* Calculated LTV */}
            <div className="bg-slate-900/60 rounded-lg p-2.5 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block font-medium">Estimated LTV</span>
              <span className="text-lg font-black text-white font-mono block mt-1">${ltv.toFixed(0)}</span>
              <p className="text-[9px] text-slate-500 mt-0.5">Average customer value</p>
            </div>

            {/* Calculated Gross Margin */}
            <div className="bg-slate-900/60 rounded-lg p-2.5 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block font-medium">Gross Margin %</span>
              <span className="text-lg font-black text-emerald-400 font-mono block mt-1">{grossMargin.toFixed(0)}%</span>
              <p className="text-[9px] text-slate-500 mt-0.5">Industry avg: 50-70%</p>
            </div>
          </div>

          {/* Ratio Progress Visualizer */}
          <div className="bg-slate-900/60 rounded-lg p-3 border border-slate-800/80 flex flex-col gap-2">
            <div className="flex justify-between items-end">
              <div className="flex flex-col">
                <span className="text-[10px] text-slate-400 font-semibold">LTV / CAC RATIO</span>
                <span className="text-2xl font-black text-white font-mono mt-0.5">
                  {ltvCacRatio.toFixed(2)}x
                </span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">Target: ≥ 3.00x</span>
            </div>

            {/* Visual Bar gauge */}
            <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-850/50 flex">
              <div
                className={`h-full transition-all duration-300 ${badgeColor}`}
                style={{ width: `${Math.min((ltvCacRatio / 4) * 100, 100)}%` }}
              />
            </div>
          </div>

          {/* Status Badge */}
          <div className={`p-2.5 rounded-lg text-center text-xs font-extrabold border ${statusColor} transition-colors duration-200`}>
            {statusText}
          </div>
        </div>
      </div>
    </div>
  );
}
