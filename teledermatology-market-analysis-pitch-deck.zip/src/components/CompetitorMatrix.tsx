import { useState } from 'react';
import { competitors } from '../data';
import { Check, X, ShieldAlert, Award, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function CompetitorMatrix() {
  const [selectedComp, setSelectedComp] = useState<string>(competitors[0].name);

  const activeComp = competitors.find(c => c.name === selectedComp) || competitors[0];

  return (
    <div className="bg-slate-900/40 border border-slate-800/80 backdrop-blur-md rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
      <div>
        <h4 className="text-white font-bold text-sm tracking-tight flex items-center gap-1.5">
          <Award className="w-4 h-4 text-orange-400" />
          Teledermatology Competitive Landscape Matrix
        </h4>
        <p className="text-slate-400 text-xs mt-0.5">
          Compare competitors across business models, target markets, pricing, and key strategic features.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Competitor Grid Picker */}
        <div className="lg:col-span-5 flex flex-col gap-2">
          {competitors.map((c) => {
            const isSelected = c.name === selectedComp;
            return (
              <button
                key={c.name}
                id={`comp-btn-${c.name.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => setSelectedComp(c.name)}
                className={`text-left p-3 rounded-xl border transition-all duration-200 flex items-center justify-between ${
                  isSelected
                    ? 'bg-orange-950/20 border-orange-900/40 shadow-[0_0_15px_rgba(249,115,22,0.1)] text-orange-400 font-semibold'
                    : 'bg-slate-950/60 hover:bg-slate-900 border-slate-850/80 text-slate-300'
                }`}
              >
                <div className="flex flex-col gap-0.5">
                  <span className={`text-xs font-bold leading-tight ${isSelected ? 'text-orange-400' : 'text-slate-300'}`}>{c.name}</span>
                  <span className={`text-[10px] font-normal max-w-[180px] truncate ${isSelected ? 'text-orange-300/80' : 'text-slate-500'}`}>{c.model}</span>
                </div>
                <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isSelected ? 'text-orange-400 translate-x-1' : 'text-slate-600'}`} />
              </button>
            );
          })}
        </div>

        {/* Competitor Details View */}
        <div className="lg:col-span-7 bg-slate-950/40 rounded-xl p-4 border border-slate-800/80 flex flex-col justify-between h-[230px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedComp}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.15 }}
              className="flex flex-col gap-3 h-full"
            >
              {/* Header Details */}
              <div className="flex justify-between items-start border-b border-slate-850 pb-2.5">
                <div>
                  <h5 className="text-xs font-extrabold text-white">{activeComp.name}</h5>
                  <p className="text-[10px] text-slate-400 mt-0.5 font-medium">{activeComp.model}</p>
                </div>
                <div className="text-right">
                  <span className="bg-slate-900 text-slate-300 font-mono text-[9px] font-bold px-2 py-0.5 rounded-md border border-slate-800">
                    {activeComp.pricing}
                  </span>
                  <p className="text-[9px] text-slate-500 mt-1 font-medium">Target: {activeComp.target}</p>
                </div>
              </div>

              {/* Strengths & Weaknesses Grid */}
              <div className="grid grid-cols-2 gap-3 flex-1 overflow-y-auto pr-1">
                {/* Strengths */}
                <div className="flex flex-col gap-1.5">
                  <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                    <Check className="w-3 h-3 stroke-[3]" />
                    Strengths
                  </span>
                  <ul className="flex flex-col gap-1 text-[10px] text-slate-300">
                    {activeComp.strengths.map((str, index) => (
                      <li key={index} className="flex items-start gap-1">
                        <span className="text-emerald-400 font-bold">•</span>
                        <span>{str}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Weaknesses */}
                <div className="flex flex-col gap-1.5">
                  <span className="text-[10px] font-bold text-rose-400 flex items-center gap-1">
                    <X className="w-3 h-3 stroke-[3]" />
                    Weaknesses
                  </span>
                  <ul className="flex flex-col gap-1 text-[10px] text-slate-300">
                    {activeComp.weaknesses.map((weak, index) => (
                      <li key={index} className="flex items-start gap-1">
                        <span className="text-rose-400 font-bold">•</span>
                        <span>{weak}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
