import { Slide, Competitor, PDFInsight } from './types';

export const competitors: Competitor[] = [
  {
    name: 'Teladoc Health',
    model: 'General Telehealth (DermatologistOnCall asynch)',
    pricing: '$95 per consult (or $0 with coverage)',
    target: 'Broad - insured or self-pay patients',
    strengths: ['Strong national brand recognition', 'Integrated with employer benefits', 'Large provider network'],
    weaknesses: ['Generalist model (not specialty-first)', 'Margins shared with main platform', 'Heavy general competition']
  },
  {
    name: 'Doctor On Demand',
    model: 'Live Video (Included Health platform)',
    pricing: '$99 self-pay (or $0 with coverage)',
    target: 'Patients preferring live face-to-face video',
    strengths: ['Real-time 15-20 min visits', 'Fast access (avg 10-min wait)', 'Strong reputation in telehealth'],
    weaknesses: ['Requires appointment scheduling', 'Moles/spots need high-res imaging', 'Higher cost per consultation']
  },
  {
    name: 'MDLive',
    model: 'Asynchronous (Evernorth/Cigna group)',
    pricing: '$0 - $95 (copays as low as $0)',
    target: 'Insured members of Evernorth/Cigna & other plans',
    strengths: ['Large insurance distribution', '24/7 access, 90% first-visit resolution', 'Secure photo uploads'],
    weaknesses: ['Less recognized standalone brand', 'No in-house cosmetic RX options', 'Post-acquisition platform lock-in']
  },
  {
    name: 'Curology',
    model: 'Direct-to-Consumer Subscription (Acne Rx)',
    pricing: '$25 - $40/month plus medications',
    target: 'Younger consumers with acne or skincare goals',
    strengths: ['Highly personalized skin quiz', 'Strong viral marketing & social media', 'Low CAC via digital channels'],
    weaknesses: ['Extremely focused on mild acne', 'Not suitable for full dermatology care', 'Heavy marketing spend required']
  },
  {
    name: 'DirectDerm',
    model: 'Hybrid (Telederm + Physical Clinics)',
    pricing: 'Affordable self-pay or insurance billing',
    target: 'Patients wanting a hybrid care continuum',
    strengths: ['Offline clinics for biopsies/procedures', 'Highly trusted local doctors', 'Insurance partnerships'],
    weaknesses: ['Regional footprint (mainly California)', 'Slower national brand awareness', 'Higher OPEX due to brick-and-mortar']
  }
];

export const slides: Slide[] = [
  {
    id: 1,
    title: 'US Teledermatology Market Analysis',
    subtitle: 'Market Entry Evaluation & Opportunity Assessment',
    theme: 'neutral',
    speakerNotes: [
      'Welcome everyone to the Market Entry Evaluation for US Teledermatology.',
      'Dermatology is uniquely suited for virtual care because it relies primarily on visual inspection.',
      'Today, we will analyze the rapid expansion, competitive gaps, regulatory hurdles, unit economics, and our final strategic recommendation.',
      'Prepared by: Anish Bera.'
    ]
  },
  {
    id: 2,
    title: 'Market Opportunity',
    subtitle: 'High Growth, Large Unmet Need & Strong Consumer Demand',
    theme: 'blue',
    speakerNotes: [
      'The US teledermatology market is projected to grow from $4.3B in 2024 to $11.3B in 2030, a powerful 17% CAGR.',
      'Historical context: Growth exploded during COVID-19. Kaiser Permanente went from under 30% to over 95% virtual visits.',
      'Demand drivers are massive: 50M Americans suffer from acne, 30M from eczema, 7.5M from psoriasis.',
      'Shortage constraint: There are only ~3.4 dermatologists per 100k people, resulting in wait times averaging 4 months for in-person visits.',
      'Conclusion: This is a highly attractive market characterized by massive volume and a clear bottleneck.'
    ]
  },
  {
    id: 3,
    title: 'Competitive Landscape',
    subtitle: 'Analysis of Existing Telehealth and DTC Skincare Models',
    theme: 'neutral',
    speakerNotes: [
      'We categorize key competitors into three main clusters:',
      '1. Generalist Telehealth (Teladoc Health, Doctor on Demand, MDLive) charging $95-$99 per consult.',
      '2. Direct-To-Consumer Skincare Subscriptions (Curology, GoodRx Care) charging $25-$40/month but limited strictly to acne.',
      '3. Hybrid local players (DirectDerm) combining asynchronous digital care with regional brick-and-mortar clinics.',
      'Each model has strong distribution or pricing points, but they leave key customer needs unaddressed.'
    ]
  },
  {
    id: 4,
    title: 'Competitor Comparison',
    subtitle: 'Identifying the White Space / Market Gap',
    theme: 'orange',
    speakerNotes: [
      'While general networks have strong brands and insurance contracts, they suffer from critical weaknesses:',
      'They rely on one-time transactional consultations rather than managing chronic, long-term conditions.',
      'There is poor management of chronic skin diseases like eczema or psoriasis which require continuous follow-ups.',
      'Market Gap: NO major company owns long-term, specialized, dermatology-first care.',
      'Opportunity: AI-assisted screening, pediatric care, and continuous chronic skin monitoring are completely wide open.'
    ]
  },
  {
    id: 5,
    title: 'Regulations & Compliance',
    subtitle: 'Navigating Legal, Billing & Licensure Hurdles',
    theme: 'red',
    speakerNotes: [
      'Stringent regulations make operations complex. Clinicians must be licensed in the exact state where the patient resides.',
      'Multi-state licensing and credentialing remains the single hardest operational hurdle for a nationwide platform.',
      'HIPAA compliance is mandatory for all images and transcripts, requiring encrypted storage and secure data-sharing.',
      'Reimbursement is highly fragmented. Medicaid coverage exists in 48 states, but only 4 states have unrestricted parity.',
      'Medicare does not currently cover asynchronous "store-and-forward" consultations, limiting it to rural live-video.'
    ]
  },
  {
    id: 6,
    title: 'Unit Economics',
    subtitle: 'Financial Benchmarks and the Importance of Retention',
    theme: 'neutral',
    speakerNotes: [
      'Let us review the standard benchmarks for store-and-forward teledermatology consultations.',
      'Self-pay visits are priced around $95, with a clinical labor cost of ~$40 per consult (based on board-certified dermatologists handling 3-5 cases per hour). This yields a 50-70% gross margin.',
      'Customer Acquisition Cost (CAC) is high, ranging from $100 to $200 (direct-to-consumer standard is ~$100).',
      'If patients only use the service once, average lifetime revenue is $150-$200, which barely covers CAC.',
      'Conclusion: Winning requires pushing LTV to $300+ via recurring chronic care, achieving the target LTV/CAC ratio of >= 3.'
    ]
  },
  {
    id: 7,
    title: 'Assumption Companies Get Wrong',
    subtitle: 'Misplaced Assumptions vs. Market Realities',
    theme: 'orange',
    speakerNotes: [
      'Most newcomers assume that overall market growth guarantees startup profitability.',
      'They also assume that state regulations and insurer reimbursement will quickly align with general telehealth.',
      'In reality, acquiring customers is expensive, insurer coverage remains patchy, and patients are treated as one-offs.',
      'Nearly 70% of dermatologists report that current reimbursement rates are "too low".',
      'Winning is not about rapid customer acquisition; it is about patient retention.'
    ]
  },
  {
    id: 8,
    title: 'Why a New Company Can Still Win',
    subtitle: 'The Power of Dermatology-First Specialization',
    theme: 'blue',
    speakerNotes: [
      'A new entrant does not need to compete on price with massive generalist platforms.',
      'They can win by building a specialized teledermatology platform that offers continuous, longitudinal care.',
      'Strategic differentiators include: AI-assisted triage for early melanoma detection, pediatric specialized skin care, and localized follow-ups.',
      'Shift the value proposition: Instead of selling single-use clinical consultations, sell long-term skin health.'
    ]
  },
  {
    id: 9,
    title: 'Betting on Teledermatology',
    subtitle: 'The Ultimate Investment Thesis',
    theme: 'blue',
    speakerNotes: [
      'Why teledermatology over other telehealth categories like primary care or psychiatry?',
      'Dermatology is 100% visual, making it the perfect technological fit for remote store-and-forward imaging.',
      'It taps into a highly underserved chronic care patient base (eczema, psoriasis).',
      'Subscription models (recurring monthly fees for care plans) drastically increase LTV compared to one-time visits.',
      'With lower capital expenditures than physical clinics and a 17% CAGR, it holds the highest digital health potential.'
    ]
  },
  {
    id: 10,
    title: 'Final Recommendation',
    subtitle: 'Strategic Decision: YES to Market Entry',
    theme: 'green',
    speakerNotes: [
      'Our final recommendation is a definitive YES to market entry, but with a highly specific execution playbook.',
      'Do not build another general telehealth clone. Avoid entering the price-war on one-off self-pay consultations.',
      'Winning strategy: Build an AI-first, chronic-care-focused teledermatology platform.',
      'By focusing on continuous monitoring, personalized treatment plans, and superior mobile UX, we secure high patient retention, maximize LTV, and bypass transactional competition.'
    ]
  }
];

export const pdfInsights: PDFInsight[] = [
  {
    category: 'Market',
    title: 'Projected CAGR & Size',
    detail: 'US Teledermatology market is estimated at $4.3B in 2024 and projected to reach ~$11.3B by 2030, growing at an annual rate of ~17% CAGR.',
    metric: '17% CAGR',
    sourcePage: 1
  },
  {
    category: 'Market',
    title: 'Kaiser Permanente Benchmark',
    detail: 'During the COVID-19 pandemic, Kaiser Permanente virtual dermatology visits surged from <30% to >95%, showing an unprecedented institutional shift.',
    metric: '>95% visits',
    sourcePage: 1
  },
  {
    category: 'Market',
    title: 'Dermatologist Shortages',
    detail: 'The U.S. has a severe dermatologist shortage, averaging only 3.4 board-certified dermatologists per 100k population, leading to massive friction.',
    metric: '3.4 per 100k',
    sourcePage: 1
  },
  {
    category: 'Market',
    title: 'Dermatology Wait Times',
    detail: 'The average wait time for an in-person specialist dermatology referral is approximately 4 months, which drives users to search online.',
    metric: '4-month wait',
    sourcePage: 1
  },
  {
    category: 'Market',
    title: 'Disease Prevalence Drivers',
    detail: 'Acne affects ~50M Americans, eczema affects ~30M, and psoriasis affects ~7.5M. Additionally, there are ~9,500 skin cancer diagnoses daily.',
    metric: '87M+ patients',
    sourcePage: 1
  },
  {
    category: 'Market',
    title: 'Turnaround Speed Advantage',
    detail: 'Asynchronous store-and-forward teledermatology can deliver personalized treatment plans within 1-2 days compared to the 4-month in-person queue.',
    metric: '1-2 day turnaround',
    sourcePage: 1
  },
  {
    category: 'Competition',
    title: 'Teladoc Model & Pricing',
    detail: 'Nation-wide general network charging $95 per consult for self-pay. Patients upload photos; a board-certified dermatologist reviews asynchronously.',
    metric: '$95 per consult',
    sourcePage: 2
  },
  {
    category: 'Competition',
    title: 'Curology Subscription Focus',
    detail: 'Curology charges $25-$40/month for custom acne formulas. While highly optimized with low CAC, it is limited strictly to acne/skincare.',
    metric: '$25-$40/mo',
    sourcePage: 2
  },
  {
    category: 'Competition',
    title: 'MDLive High First-Visit Resolution',
    detail: 'Achieves ~90% first-visit resolution for photos submitted asynchronously, with turnaround times between 24 and 72 hours.',
    metric: '90% resolution',
    sourcePage: 2
  },
  {
    category: 'Competition',
    title: 'DirectDerm Hybrid Model',
    detail: 'Combines asynchronous digital screening with physical brick-and-mortar clinics for biopsies/procedures. However, this raises OPEX significantly.',
    metric: 'Hybrid Care',
    sourcePage: 2
  },
  {
    category: 'Regulation',
    title: 'State Licensure Barrier',
    detail: 'Clinicians must be licensed in the exact state where the patient resides. Multi-state credentialing is a massive operational and cost bottleneck.',
    metric: 'Strict State Law',
    sourcePage: 3
  },
  {
    category: 'Regulation',
    title: 'Medicare Restrictions',
    detail: 'Medicare still limits teledermatology coverage to live visits in rural areas and completely excludes reimbursement for asynchronous store-and-forward care.',
    metric: 'No Asynch Medicare',
    sourcePage: 3
  },
  {
    category: 'Regulation',
    title: 'Medicaid Parity Split',
    detail: 'About 48 states cover some form of teledermatology under Medicaid, but only 4 states offer unrestricted payment parity.',
    metric: '4/48 Parity States',
    sourcePage: 3
  },
  {
    category: 'Regulation',
    title: 'Standard of Care Rules',
    detail: 'Teledermatology must meet the identical clinical standard of care as in-person visits, requiring robust malpractice coverage and patient consent protocols.',
    metric: '100% Care Standard',
    sourcePage: 3
  },
  {
    category: 'Economics',
    title: 'Dermatologist Labor Cost',
    detail: 'Dermatologist clinical time is valued at $120/hour. If handling 3-5 store-and-forward visits/hour, labor cost per visit is ~$30-$50.',
    metric: '~$40/visit clinical',
    sourcePage: 4
  },
  {
    category: 'Economics',
    title: 'The Transactional Pitfall',
    detail: 'With a high direct-to-consumer CAC (~$100), if a patient only uses the service once (yielding $95 revenue), the company loses money.',
    metric: '$95 visit vs $100 CAC',
    sourcePage: 4
  },
  {
    category: 'Economics',
    title: 'Retention-Driven LTV',
    detail: 'In subscription-based or chronic care models, keeping patients for 6-12 months pushes Average Revenue per User (ARPU) to $150-$300 LTV.',
    metric: '$150-$300 LTV',
    sourcePage: 4
  },
  {
    category: 'Strategy',
    title: 'Specialized Chronic Care Winning Strategy',
    detail: 'New startups can beat general telehealth giants by focusing on longitudinal care for chronic conditions (eczema, psoriasis) instead of one-offs.',
    metric: 'Chronic Care Focus',
    sourcePage: 5
  },
  {
    category: 'Strategy',
    title: 'AI Image Triage Integration',
    detail: 'Integrating AI-driven image pre-screening helps triage high-risk lesions (like melanoma) instantly, improving dermatologist throughput and clinical safety.',
    metric: 'AI-Powered Triage',
    sourcePage: 5
  }
];
